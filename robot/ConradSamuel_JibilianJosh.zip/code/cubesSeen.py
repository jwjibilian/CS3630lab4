class cubesSeen:
    cubes = []

    def append(self, i):
        self.cubes.append(i)

    def getCubes(self):
        return self.cubes